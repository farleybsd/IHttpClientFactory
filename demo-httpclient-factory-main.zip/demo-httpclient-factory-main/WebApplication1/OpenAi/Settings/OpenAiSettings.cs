namespace WebApplication1.OpenAi.Settings;

public class OpenAiSettings
{
    public string BaseAddress { get; init; } = "";
    
    public string ApiKey { get; init; } = "";
}