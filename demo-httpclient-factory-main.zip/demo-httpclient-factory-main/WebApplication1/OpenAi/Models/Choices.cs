namespace WebApplication1.OpenAi.Models;

public record Choices(Message Message);