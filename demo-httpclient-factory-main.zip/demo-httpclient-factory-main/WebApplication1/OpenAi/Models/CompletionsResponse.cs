namespace WebApplication1.OpenAi.Models;

public record CompletionsResponse(Choices[] Choices);