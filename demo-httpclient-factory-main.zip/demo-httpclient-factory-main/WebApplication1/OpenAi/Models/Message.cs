namespace WebApplication1.OpenAi.Models;

public record Message(string Role, string Content);