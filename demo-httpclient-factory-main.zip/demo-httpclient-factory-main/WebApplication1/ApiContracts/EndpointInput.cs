namespace WebApplication1.ApiContracts;

public record EndpointInput(string Prompt);