namespace WebApplication1.ApiContracts;

public record EndpointOutput(string Response);